using System;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEngine.Experimental.Rendering;

namespace RetroShadersPro.URP.Editor
{
    internal class RetroTerrainLitShaderGUI : ShaderGUI, ITerrainLayerCustomUI
    {
        private class StylesLayer
        {
            public readonly GUIContent warningHeightBasedBlending = new GUIContent("Height-based blending is disabled if you have more than four TerrainLayer materials!");

            public readonly GUIContent enableHeightBlend = new GUIContent("Enable Height-based Blend", "Blend terrain layers based on height values.");
            public readonly GUIContent heightTransition = new GUIContent("Height Transition", "Size in world units of the smooth transition between layers.");
            public readonly GUIContent enableInstancedPerPixelNormal = new GUIContent("Enable Per-pixel Normal", "Enable per-pixel normal when the terrain uses instanced rendering.");

            public readonly GUIContent diffuseTexture = new GUIContent("Diffuse");
            public readonly GUIContent colorTint = new GUIContent("Color Tint");
            public readonly GUIContent opacityAsDensity = new GUIContent("Opacity as Density", "Enable Density Blend (if unchecked, opacity is used as Smoothness)");
            public readonly GUIContent normalMapTexture = new GUIContent("Normal Map");
            public readonly GUIContent normalScale = new GUIContent("Normal Scale");
            public readonly GUIContent maskMapTexture = new GUIContent("Mask", "R: Metallic\nG: AO\nB: Height\nA: Smoothness");
            public readonly GUIContent maskMapTextureWithoutHeight = new GUIContent("Mask Map", "R: Metallic\nG: AO\nA: Smoothness");
            public readonly GUIContent channelRemapping = new GUIContent("Channel Remapping");
            public readonly GUIContent defaultValues = new GUIContent("Channel Default Values");
            public readonly GUIContent metallic = new GUIContent("R: Metallic");
            public readonly GUIContent ao = new GUIContent("G: AO");
            public readonly GUIContent height = new GUIContent("B: Height");
            public readonly GUIContent heightParametrization = new GUIContent("Parametrization");
            public readonly GUIContent heightAmplitude = new GUIContent("Amplitude (cm)");
            public readonly GUIContent heightBase = new GUIContent("Base (cm)");
            public readonly GUIContent heightMin = new GUIContent("Min (cm)");
            public readonly GUIContent heightMax = new GUIContent("Max (cm)");
            public readonly GUIContent heightCm = new GUIContent("B: Height (cm)");
            public readonly GUIContent smoothness = new GUIContent("A: Smoothness");
        }

        static StylesLayer s_Styles = null;
        private static StylesLayer styles { get { if (s_Styles == null) s_Styles = new StylesLayer(); return s_Styles; } }

        // Height blend params
        MaterialProperty enableHeightBlend = null;
        const string kEnableHeightBlend = "_EnableHeightBlend";

        MaterialProperty heightTransition = null;
        const string kHeightTransition = "_HeightTransition";

        // Retro parameters.
        private RetroShaderProperty colorBitDepth = new("_ColorBitDepth", "Color Depth", "Limits the total number of values used for each color channel.");
        private RetroShaderProperty colorBitDepthOffset = new("_ColorBitDepthOffset", "Color Depth Offset", "Increase this value if the bit depth offset makes your object too dark.");
        private RetroShaderProperty resolutionLimit = new("_ResolutionLimit", "Resolution Limit",
            "Limits the resolution of the texture to this value." +
            "\nNote that this setting only snaps the resolution to powers of two." +
            "\nAlso, make sure the Base Texture has mipmaps enabled.");
        
        private RetroShaderProperty filteringMode = new("_FilterMode", "Filtering Mode",
            "Which kind of filtering should the shader use while sampling the base texture?" +
            "\n  Bilinear: Blend between the nearest 4 pixels, which appears smooth." +
            "\n  Point: Use nearest neighbor sampling, which appears blocky." +
            "\n  N64: Use the limited 3-point sampling method from the Nintendo 64.");

        private RetroShaderProperty ditheringMode = new("_DitherMode", "Dithering Mode",
            "How should the shader dither colors which fall between color bit values?" +
            "\n  Screen: Use screen-space coordinates for dithering." +
            "\n    Note that this mode is driven by the pixel size in the CRT post process." +
            "\n  Texture: Use the texture coordinates for dithering." +
            "\n  Off: Don't use any dithering.");

        private RetroShaderProperty useVertexColor = new("_USE_VERTEX_COLORS", "Use Vertex Colors",
            "Should the base color of the object use vertex coloring?");

        private RetroShaderProperty snappingMode = new("_SnapMode", "Snapping Mode",
            "Should the shader snap vertices to a limited number of points in space?" +
            "\n  Object: Snap vertices relative to model coordinates." +
            "\n  World: Snap vertices relative to the scene coordinates." +
            "\n  View: Snap vertices relative to the camera coordinates." +
            "\n  Off: Don't do any snapping.");

        private RetroShaderProperty snapsPerUnit = new("_SnapsPerUnit", "Snaps Per Meter",
            "The mesh vertices snap to a limited number of points in space." +
            "\nThis uses view space, so the mesh may jitter when the camera rotates.");

        private RetroShaderProperty lightingMode = new("_LightMode", "Lighting Mode",
            "Choose how the object should be lit." +
            "\n  Lit: Use per-pixel lighting as standard." +
            "\n  Texel Lit: Snap lighting and shadows to the closest texel on the object's texture." +
            "\n  Vertex Lit: Use per-vertex lighting and interpolate light values for pixels." +
            "\n  Unlit: Don't use lighting calculations (everything is always fully lit)." +
            "\n\nNote that for the terrain shader, in Texel Lit mode, lighting only snaps to the first texture layer - for best results, use the same texture resolution for all layers.");

        private RetroShaderProperty receiveShadowsMode = new("_ReceiveShadowsMode", "Receive Shadows",
            "Should the object receive shadows from other objects?");
        private RetroShaderProperty ambientToggle = new("_USE_AMBIENT_OVERRIDE", "Ambient Light Override",
            "Should the object use Unity's default ambient light, or a custom override amount?");
        private RetroShaderProperty ambientLight = new("_AmbientLight", "Ambient Light Strength",
            "When the ambient light override is used, apply this much ambient light.");
        private RetroShaderProperty useSpecularLight = new("_USE_SPECULAR_LIGHT","Use Specular Lighting",
            "Should the shader apply a specular highlight to the object?");
        private RetroShaderProperty glossiness = new("_Glossiness","Glossiness",
            "Gloss power value to use for specular lighting. The higher this value is, the smaller the highlight appears on the surface of the object.");
        private RetroShaderProperty useReflectionCubemap = new("_USE_REFLECTION_CUBEMAP","Use Reflection Cubemap",
            "Should the shader overlay a cubemap which contains environmental reflections?");
        private RetroShaderProperty reflectionCubemap = new("_ReflectionCubemap","Reflection Cubemap",
            "A cubemap which contains environmental reflections.");
        private RetroShaderProperty cubemapColor = new("_CubemapColor", "Cubemap Color",
            "A color tint applied to the cubemap. The alpha channel acts as a strength multiplier.");
        private RetroShaderProperty cubemapRotation = new("_CubemapRotation", "Cubemap Rotation",
            "How much to rotate the reflection cubemap around the Y-axis, in degrees.");
        private RetroShaderProperty useStochasticTexturing = new("_USE_STOCHASTIC_TEXTURING", "Use Stochastic Texturing", "Use random UV offsets in chunks to break up texture tiling.");

        private static GUIStyle _boxStyle;
        private static GUIStyle BoxStyle
        {
            get
            {
                return _boxStyle ?? (_boxStyle = new GUIStyle(EditorStyles.helpBox)
                {
                    padding = new RectOffset(10, 10, 5, 10)
                });
            }
        }

        private static GUIStyle _labelStyle;
        private static GUIStyle LabelStyle
        {
            get
            {
                return _labelStyle ?? (_labelStyle = new GUIStyle(EditorStyles.boldLabel));
            }
        }

        // Per-pixel Normal (while instancing)
        MaterialProperty enableInstancedPerPixelNormal = null;
        const string kEnableInstancedPerPixelNormal = "_EnableInstancedPerPixelNormal";

        private bool m_ShowChannelRemapping = false;
        enum HeightParametrization
        {
            Amplitude,
            MinMax
        };
        private HeightParametrization m_HeightParametrization = HeightParametrization.Amplitude;

        private static bool DoesTerrainUseMaskMaps(TerrainLayer[] terrainLayers)
        {
            for (int i = 0; i < terrainLayers.Length; ++i)
            {
                if (terrainLayers[i].maskMapTexture != null)
                    return true;
            }
            return false;
        }

        protected void FindMaterialProperties(MaterialProperty[] props)
        {
            enableHeightBlend = FindProperty(kEnableHeightBlend, props, false);
            heightTransition = FindProperty(kHeightTransition, props, false);
            enableInstancedPerPixelNormal = FindProperty(kEnableInstancedPerPixelNormal, props, false);

            resolutionLimit.prop = FindProperty(resolutionLimit.name, props, true);
            snappingMode.prop = FindProperty(snappingMode.name, props, true);
            snapsPerUnit.prop = FindProperty(snapsPerUnit.name, props, true);
            colorBitDepth.prop = FindProperty(colorBitDepth.name, props, true);
            colorBitDepthOffset.prop = FindProperty(colorBitDepthOffset.name, props, true);
            ambientLight.prop = FindProperty(ambientLight.name, props, true);
            ambientToggle.prop = FindProperty(ambientToggle.name, props, true);
            filteringMode.prop = FindProperty(filteringMode.name, props, true);
            ditheringMode.prop = FindProperty(ditheringMode.name, props, true);
            lightingMode.prop = FindProperty(lightingMode.name, props, true);
            receiveShadowsMode.prop = FindProperty(receiveShadowsMode.name, props, true);
            useVertexColor.prop = FindProperty(useVertexColor.name, props, true);
            useSpecularLight.prop = FindProperty(useSpecularLight.name, props, true);
            glossiness.prop = FindProperty(glossiness.name, props, true);
            useReflectionCubemap.prop = FindProperty(useReflectionCubemap.name, props, true);
            reflectionCubemap.prop = FindProperty(reflectionCubemap.name, props, true);
            cubemapColor.prop = FindProperty(cubemapColor.name, props, true);
            cubemapRotation.prop = FindProperty(cubemapRotation.name, props, true);
            useStochasticTexturing.prop = FindProperty(useStochasticTexturing.name, props, true);
        }

        static public void SetupMaterialKeywords(Material material)
        {
            bool enableHeightBlend = (material.HasProperty(kEnableHeightBlend) && material.GetFloat(kEnableHeightBlend) > 0);
            CoreUtils.SetKeyword(material, "_TERRAIN_BLEND_HEIGHT", enableHeightBlend);

            bool enableInstancedPerPixelNormal = material.GetFloat(kEnableInstancedPerPixelNormal) > 0.0f;
            CoreUtils.SetKeyword(material, "_TERRAIN_INSTANCED_PERPIXEL_NORMAL", enableInstancedPerPixelNormal);
        }

        static public bool TextureHasAlpha(Texture2D inTex)
        {
            if (inTex != null)
            {
                return GraphicsFormatUtility.HasAlphaChannel(GraphicsFormatUtility.GetGraphicsFormat(inTex.format, true));
            }
            return false;
        }

        public override void OnGUI(MaterialEditor materialEditorIn, MaterialProperty[] properties)
        {
            if (materialEditorIn == null)
                throw new ArgumentNullException("materialEditorIn");

            FindMaterialProperties(properties);
            var material = materialEditorIn.target as Material;

            bool optionsChanged = false;
            EditorGUI.BeginChangeCheck();
            {
                if (enableHeightBlend != null)
                {
                    EditorGUI.indentLevel++;
                    materialEditorIn.ShaderProperty(enableHeightBlend, styles.enableHeightBlend);
                    if (enableHeightBlend.floatValue > 0)
                    {
                        EditorGUI.indentLevel++;
                        EditorGUILayout.HelpBox(styles.warningHeightBasedBlending.text, MessageType.Info);
                        materialEditorIn.ShaderProperty(heightTransition, styles.heightTransition);
                        EditorGUI.indentLevel--;
                    }
                    EditorGUI.indentLevel--;
                }

                EditorGUILayout.Space();
            }
            if (EditorGUI.EndChangeCheck())
            {
                optionsChanged = true;
            }

            bool enablePerPixelNormalChanged = false;

            // Since Instanced Per-pixel normal is actually dependent on instancing enabled or not, it is not
            // important to check it in the GUI.  The shader will make sure it is enabled/disabled properly.s
            if (enableInstancedPerPixelNormal != null)
            {
                EditorGUI.indentLevel++;
                EditorGUI.BeginChangeCheck();
                materialEditorIn.ShaderProperty(enableInstancedPerPixelNormal, styles.enableInstancedPerPixelNormal);
                enablePerPixelNormalChanged = EditorGUI.EndChangeCheck();
                EditorGUI.indentLevel--;
            }

            if (optionsChanged || enablePerPixelNormalChanged)
            {
                foreach (var obj in materialEditorIn.targets)
                {
                    SetupMaterialKeywords((Material)obj);
                }
            }

            EditorGUILayout.Space();

            EditorGUI.indentLevel++;

            EditorGUILayout.BeginVertical(BoxStyle);

            EditorGUILayout.LabelField("Color & Texture Effects", LabelStyle);
            EditorGUILayout.Space(5);

            EditorGUILayout.Space(5);
            materialEditorIn.ShaderProperty(colorBitDepth.prop, colorBitDepth.info);
            materialEditorIn.ShaderProperty(colorBitDepthOffset.prop, colorBitDepthOffset.info);
            EditorGUILayout.Space(5);
            materialEditorIn.ShaderProperty(resolutionLimit.prop, resolutionLimit.info);
            EditorGUILayout.Space(5);
            materialEditorIn.ShaderProperty(filteringMode.prop, filteringMode.info);
            materialEditorIn.ShaderProperty(ditheringMode.prop, ditheringMode.info);
            EditorGUILayout.Space(5);
            materialEditorIn.ShaderProperty(useVertexColor.prop, useVertexColor.info);

            bool vertexColors = material.GetFloat(useVertexColor.id) >= 0.5f;

            if (vertexColors)
            {
                material.EnableKeyword(useVertexColor.name);
            }
            else
            {
                material.DisableKeyword(useVertexColor.name);
            }
            
            EditorGUI.BeginChangeCheck();
            materialEditorIn.ShaderProperty(useStochasticTexturing.prop, useStochasticTexturing.info);

            if (EditorGUI.EndChangeCheck())
            {
                if (material.GetFloat(useStochasticTexturing.name) > 0.5f)
                {
                    material.EnableKeyword(useStochasticTexturing.name);
                }
                else
                {
                    material.DisableKeyword(useStochasticTexturing.name);
                }
            }

            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            EditorGUILayout.BeginVertical(BoxStyle);

            EditorGUILayout.LabelField("Vertex Snapping", LabelStyle);
            EditorGUILayout.Space(5);

            materialEditorIn.ShaderProperty(snappingMode.prop, snappingMode.info);

            if (material.GetInteger(snappingMode.id) != 3) // Off.
            {
                EditorGUI.indentLevel++;
                materialEditorIn.ShaderProperty(snapsPerUnit.prop, snapsPerUnit.info);
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            EditorGUILayout.BeginVertical(BoxStyle);

            EditorGUILayout.LabelField("Lighting & Shadows", LabelStyle);
            EditorGUILayout.Space(5);

            materialEditorIn.ShaderProperty(lightingMode.prop, lightingMode.info);

            int lightMode = material.GetInteger(lightingMode.id);

            if (lightMode != 3) // Unlit.
            {
                materialEditorIn.ShaderProperty(receiveShadowsMode.prop, receiveShadowsMode.info);
                materialEditorIn.ShaderProperty(ambientToggle.prop, ambientToggle.info);

                bool ambient = material.GetFloat(ambientToggle.id) >= 0.5f;

                if (ambient)
                {
                    material.EnableKeyword(ambientToggle.name);

                    EditorGUI.indentLevel++;
                    materialEditorIn.ShaderProperty(ambientLight.prop, ambientLight.info);
                    EditorGUI.indentLevel--;
                }
                else
                {
                    material.DisableKeyword(ambientToggle.name);
                }

                materialEditorIn.ShaderProperty(useSpecularLight.prop, useSpecularLight.info);

                bool useSpecularLighting = material.GetFloat(useSpecularLight.id) >= 0.5f;

                if (useSpecularLighting)
                {
                    material.EnableKeyword(useSpecularLight.name);

                    EditorGUI.indentLevel++;
                    materialEditorIn.ShaderProperty(glossiness.prop, glossiness.info);
                    EditorGUI.indentLevel--;
                }
                else
                {
                    material.DisableKeyword(useSpecularLight.name);
                }

                materialEditorIn.ShaderProperty(useReflectionCubemap.prop, useReflectionCubemap.info);

                if (material.GetFloat(useReflectionCubemap.id) >= 0.5f)
                {
                    material.EnableKeyword(useReflectionCubemap.name);

                    EditorGUI.indentLevel++;
                    materialEditorIn.TexturePropertyWithHDRColor(reflectionCubemap.info, reflectionCubemap.prop, cubemapColor.prop, true);
                    materialEditorIn.ShaderProperty(cubemapRotation.prop, cubemapRotation.info);
                    EditorGUI.indentLevel--;
                }
                else
                {
                    material.DisableKeyword(useReflectionCubemap.name);
                }
            }

            EditorGUILayout.EndVertical();

            EditorGUI.indentLevel--;

            // We should always do this call at the end
            materialEditorIn.serializedObject.ApplyModifiedProperties();
        }

        bool ITerrainLayerCustomUI.OnTerrainLayerGUI(TerrainLayer terrainLayer, Terrain terrain)
        {
            var terrainLayers = terrain.terrainData.terrainLayers;

            // Don't use the member field enableHeightBlend as ShaderGUI.OnGUI might not be called if the material UI is folded.
            // heightblend shouldn't be available if we are in multi-pass mode, because it is guaranteed to be broken.
            bool heightBlendAvailable = (terrainLayers.Length <= 4);
            bool heightBlend = heightBlendAvailable && terrain.materialTemplate.HasProperty(kEnableHeightBlend) && (terrain.materialTemplate.GetFloat(kEnableHeightBlend) > 0);

            terrainLayer.diffuseTexture = EditorGUILayout.ObjectField(styles.diffuseTexture, terrainLayer.diffuseTexture, typeof(Texture2D), false) as Texture2D;
            TerrainLayerUtility.ValidateDiffuseTextureUI(terrainLayer.diffuseTexture);

            var diffuseRemapMin = terrainLayer.diffuseRemapMin;
            var diffuseRemapMax = terrainLayer.diffuseRemapMax;
            EditorGUI.BeginChangeCheck();

            bool enableDensity = false;
            if (terrainLayer.diffuseTexture != null)
            {
                var rect = GUILayoutUtility.GetLastRect();
                rect.y += 16 + 4;
                rect.width = EditorGUIUtility.labelWidth + 64;
                rect.height = 16;

                ++EditorGUI.indentLevel;

                var diffuseTint = new Color(diffuseRemapMax.x, diffuseRemapMax.y, diffuseRemapMax.z);
                diffuseTint = EditorGUI.ColorField(rect, styles.colorTint, diffuseTint, true, false, false);
                diffuseRemapMax.x = diffuseTint.r;
                diffuseRemapMax.y = diffuseTint.g;
                diffuseRemapMax.z = diffuseTint.b;
                diffuseRemapMin.x = diffuseRemapMin.y = diffuseRemapMin.z = 0;

                if (!heightBlend)
                {
                    rect.y = rect.yMax + 2;
                    enableDensity = EditorGUI.Toggle(rect, styles.opacityAsDensity, diffuseRemapMin.w > 0);
                }

                --EditorGUI.indentLevel;
            }
            diffuseRemapMax.w = 1;
            diffuseRemapMin.w = enableDensity ? 1 : 0;

            if (EditorGUI.EndChangeCheck())
            {
                terrainLayer.diffuseRemapMin = diffuseRemapMin;
                terrainLayer.diffuseRemapMax = diffuseRemapMax;
            }

            // Display normal map UI
            terrainLayer.normalMapTexture = EditorGUILayout.ObjectField(styles.normalMapTexture, terrainLayer.normalMapTexture, typeof(Texture2D), false) as Texture2D;
            TerrainLayerUtility.ValidateNormalMapTextureUI(terrainLayer.normalMapTexture, TerrainLayerUtility.CheckNormalMapTextureType(terrainLayer.normalMapTexture));

            if (terrainLayer.normalMapTexture != null)
            {
                var rect = GUILayoutUtility.GetLastRect();
                rect.y += 16 + 4;
                rect.width = EditorGUIUtility.labelWidth + 64;
                rect.height = 16;

                ++EditorGUI.indentLevel;
                terrainLayer.normalScale = EditorGUI.FloatField(rect, styles.normalScale, terrainLayer.normalScale);
                --EditorGUI.indentLevel;
            }

            // Display the mask map UI and the remap controls
            terrainLayer.maskMapTexture = EditorGUILayout.ObjectField(heightBlend ? styles.maskMapTexture : styles.maskMapTextureWithoutHeight, terrainLayer.maskMapTexture, typeof(Texture2D), false) as Texture2D;
            TerrainLayerUtility.ValidateMaskMapTextureUI(terrainLayer.maskMapTexture);

            var maskMapRemapMin = terrainLayer.maskMapRemapMin;
            var maskMapRemapMax = terrainLayer.maskMapRemapMax;
            var smoothness = terrainLayer.smoothness;
            var metallic = terrainLayer.metallic;

            ++EditorGUI.indentLevel;
            EditorGUI.BeginChangeCheck();

            m_ShowChannelRemapping = EditorGUILayout.Foldout(m_ShowChannelRemapping, terrainLayer.maskMapTexture != null ? s_Styles.channelRemapping : s_Styles.defaultValues);

            if (m_ShowChannelRemapping)
            {
                if (terrainLayer.maskMapTexture != null)
                {
                    float min, max;
                    min = maskMapRemapMin.x; max = maskMapRemapMax.x;
                    EditorGUILayout.MinMaxSlider(s_Styles.metallic, ref min, ref max, 0, 1);
                    maskMapRemapMin.x = min; maskMapRemapMax.x = max;

                    min = maskMapRemapMin.y; max = maskMapRemapMax.y;
                    EditorGUILayout.MinMaxSlider(s_Styles.ao, ref min, ref max, 0, 1);
                    maskMapRemapMin.y = min; maskMapRemapMax.y = max;

                    if (heightBlend)
                    {
                        EditorGUILayout.LabelField(styles.height);
                        ++EditorGUI.indentLevel;
                        m_HeightParametrization = (HeightParametrization)EditorGUILayout.EnumPopup(styles.heightParametrization, m_HeightParametrization);
                        if (m_HeightParametrization == HeightParametrization.Amplitude)
                        {
                            // (height - heightBase) * amplitude
                            float amplitude = Mathf.Max(maskMapRemapMax.z - maskMapRemapMin.z, Mathf.Epsilon); // to avoid divide by zero
                            float heightBase = maskMapRemapMin.z / amplitude;
                            amplitude = EditorGUILayout.FloatField(styles.heightAmplitude, amplitude * 100) / 100;
                            heightBase = EditorGUILayout.FloatField(styles.heightBase, heightBase * 100) / 100;
                            maskMapRemapMin.z = heightBase * amplitude;
                            maskMapRemapMax.z = (1.0f - heightBase) * amplitude;
                        }
                        else
                        {
                            maskMapRemapMin.z = EditorGUILayout.FloatField(styles.heightMin, maskMapRemapMin.z * 100) / 100;
                            maskMapRemapMax.z = EditorGUILayout.FloatField(styles.heightMax, maskMapRemapMax.z * 100) / 100;
                        }
                        --EditorGUI.indentLevel;
                    }

                    min = maskMapRemapMin.w; max = maskMapRemapMax.w;
                    EditorGUILayout.MinMaxSlider(s_Styles.smoothness, ref min, ref max, 0, 1);
                    maskMapRemapMin.w = min; maskMapRemapMax.w = max;
                }
                else
                {
                    metallic = EditorGUILayout.Slider(s_Styles.metallic, metallic, 0, 1);
                    // AO and Height are still exclusively controlled via the maskRemap controls
                    // metallic and smoothness have their own values as fields within the LayerData.
                    maskMapRemapMax.y = EditorGUILayout.Slider(s_Styles.ao, maskMapRemapMax.y, 0, 1);
                    if (heightBlend)
                    {
                        maskMapRemapMax.z = EditorGUILayout.FloatField(s_Styles.heightCm, maskMapRemapMax.z * 100) / 100;
                    }

                    // There's a possibility that someone could slide max below the existing min value
                    // so we'll just protect against that by locking the min value down a little bit.
                    // In the case of height (Z), we are trying to set min to no lower than zero value unless
                    // max goes negative.  Zero is a good sensible value for the minimum.  For AO (Y), we
                    // don't need this extra protection step because the UI blocks us from going negative
                    // anyway.  In both cases, pushing the slider below the min value will lock them together,
                    // but min will be "left behind" if you go back up.
                    maskMapRemapMin.y = Mathf.Min(maskMapRemapMin.y, maskMapRemapMax.y);
                    maskMapRemapMin.z = Mathf.Min(Mathf.Max(0, maskMapRemapMin.z), maskMapRemapMax.z);

                    if (TextureHasAlpha(terrainLayer.diffuseTexture))
                    {
                        GUIStyle warnStyle = new GUIStyle(GUI.skin.label);
                        warnStyle.wordWrap = true;
                        GUILayout.Label("Smoothness is controlled by diffuse alpha channel", warnStyle);
                    }
                    else
                        smoothness = EditorGUILayout.Slider(s_Styles.smoothness, smoothness, 0, 1);
                }
            }

            if (EditorGUI.EndChangeCheck())
            {
                terrainLayer.maskMapRemapMin = maskMapRemapMin;
                terrainLayer.maskMapRemapMax = maskMapRemapMax;
                terrainLayer.smoothness = smoothness;
                terrainLayer.metallic = metallic;
            }
            --EditorGUI.indentLevel;

            EditorGUILayout.Space();
            TerrainLayerUtility.TilingSettingsUI(terrainLayer);

            return true;
        }
    }
}
