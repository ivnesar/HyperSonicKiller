using UnityEngine;

/// <summary>
/// Defender NPC - Läuft mit Schild auf den Spieler zu.
///
/// ANIMANCER:
///   - States rufen typsichere Methoden auf AnimManager auf (z.B. AnimManager.PlayWalk()).
///   - 2-Layer-System: Base-Layer (Beine), Upper-Layer (Oberkörper mit ShieldBlock).
///   - Kein direkter Animator-Zugriff mehr in States.
///
/// AIM-IK:
///   - AimIK wird zentral über NpcBase gesteuert (IsAimActive + AimController).
///   - Der Defender nutzt AimIK damit der Oberkörper dem Spieler zugewandt bleibt.
///   - States setzen IsAimActive = true/false (in den meisten States true,
///     bei Stunned false).
///   - AimIK arbeitet additiv auf der ShieldBlock-Pose des Upper-Layers.
///
/// RAGDOLL:
///   - NpcRagdollController entfernt → NpcImpactTracker + NpcRagdollSwapper stattdessen.
///   - Ragdoll-Physik läuft nur noch auf gespawnten Prefabs.
/// </summary>
public class DefenderNpc : NpcBase
{
    // ════════════════════════════════════════════════════════════════════════
    #region Inspector Fields
    // ════════════════════════════════════════════════════════════════════════

    [Header("Approach")]
    [Tooltip("Stoppt bei dieser Distanz zum Spieler")]
    [SerializeField] private float approachDistance = 1.5f;

    [Tooltip("Fängt wieder an zu laufen ab dieser Distanz")]
    [SerializeField] private float reengageDistance = 3f;

    [Header("Shield Hit Reaction")]
    [Tooltip("Wie lange der Defender nach einem Schild-Treffer stehen bleibt (in Sekunden).")]
    [SerializeField] private float shieldHitReactionDuration = 0.5f;

    #endregion

    // ════════════════════════════════════════════════════════════════════════
    #region Public Accessors
    // ════════════════════════════════════════════════════════════════════════

    public float ApproachDistance => approachDistance;
    public float ReengageDistance => reengageDistance;
    public float ShieldHitReactionDuration => shieldHitReactionDuration;

    /// <summary>
    /// Typed animation manager reference for DefenderStates.
    /// </summary>
    public DefenderAnimationManager AnimManager { get; private set; }

    #endregion

    // ════════════════════════════════════════════════════════════════════════
    #region Runtime State
    // ════════════════════════════════════════════════════════════════════════

    private INpcState<DefenderNpc> currentState;

    #endregion

    // ════════════════════════════════════════════════════════════════════════
    #region NpcBase Implementation
    // ════════════════════════════════════════════════════════════════════════

    protected override void Awake()
    {
        base.Awake();

        AnimManager = GetComponentInChildren<DefenderAnimationManager>();
        if (AnimManager == null)
        {
            Debug.LogWarning($"[DefenderNpc] No DefenderAnimationManager found on {gameObject.name}! " +
                             "Animations will not work.");
        }
    }

    protected override void OnStart()
    {
        ChangeState(new DefenderStates.Idle());
    }

    protected override void UpdateBehavior()
    {
        if (currentState == null) return;

        var nextState = currentState.Update(this);
        if (nextState != null)
            ChangeState(nextState);
    }

    protected override void OnStunStart() => ChangeState(new DefenderStates.Stunned());

    protected override void OnStunEnd()
    {
        if (CurrentBehaviorMode == BehaviorMode.Pursuing)
            ChangeState(new DefenderStates.Approaching());
        else
            ChangeState(new DefenderStates.Idle());
    }

    public override string GetCurrentStateName() => currentState?.StateName ?? "None";
    public override NpcType GetNpcType() => NpcType.Defender;
    public override int GetStateID() => currentState?.StateID ?? 0;

    #endregion

    // ════════════════════════════════════════════════════════════════════════
    #region State Management
    // ════════════════════════════════════════════════════════════════════════

    public void ChangeState(INpcState<DefenderNpc> newState)
    {
        currentState?.Exit(this);
        currentState = newState;
        currentState?.Enter(this);
    }

    #endregion

    // ════════════════════════════════════════════════════════════════════════
    #region Shield Combat
    // ════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Vom Combat-System aufrufen, wenn der Spieler den Schild trifft.
    /// Wechselt in den ShieldHitReaction-State (kurzes Stagger, dann weiter).
    /// Ignoriert den Aufruf, wenn der Defender gerade gestunned oder tot ist.
    /// </summary>
    public void OnShieldBlocked()
    {
        if (IsDead || IsStunned) return;

        // Nicht unterbrechen, wenn bereits in einer Hit-Reaction
        if (currentState is DefenderStates.ShieldHitReaction) return;

        ChangeState(new DefenderStates.ShieldHitReaction());
    }

    #endregion

    // ════════════════════════════════════════════════════════════════════════
    #region Helpers
    // ════════════════════════════════════════════════════════════════════════

    public bool IsCloseEnough() => DistanceToTarget <= approachDistance;
    public bool IsTooFar() => DistanceToTarget > reengageDistance;

    public new void MoveTowardTarget(float speed = 1f) => base.MoveTowardTarget(speed);
    public new void StopMovement() => base.StopMovement();
    public new void RotateTowardTarget() => base.RotateTowardTarget();

    #endregion

    // ════════════════════════════════════════════════════════════════════════
    #region Debug
    // ════════════════════════════════════════════════════════════════════════

    protected override void OnDrawGizmosSelected()
    {
        base.OnDrawGizmosSelected();

        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, approachDistance);

        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, reengageDistance);
    }

    #endregion
}
